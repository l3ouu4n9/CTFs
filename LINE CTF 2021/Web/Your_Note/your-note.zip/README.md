```
cp .env.example .env
docker-compose build
docker-compose up -d
```