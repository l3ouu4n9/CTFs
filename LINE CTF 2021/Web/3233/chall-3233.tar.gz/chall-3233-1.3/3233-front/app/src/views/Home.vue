<template>
  <div class="home">
    <div>
      <h1>3233</h1>
      <router-link to="/login" class="button">Login</router-link>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home'
}
</script>
