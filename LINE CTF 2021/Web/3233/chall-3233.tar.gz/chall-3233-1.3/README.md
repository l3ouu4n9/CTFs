# Challenge 3233

## Description
I made a chat application. Any messages are encrypted, so it's very secure.

> Alice sends FLAG to bob every 30 seconds.