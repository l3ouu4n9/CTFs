let config = {};

config.pubkey = `-----BEGIN PUBLIC KEY-----
???
-----END PUBLIC KEY-----
`;
config.privkey = `-----BEGIN RSA PRIVATE KEY-----
???
-----END RSA PRIVATE KEY-----
`;
config.flag = "union{???}";

module.exports = config;
