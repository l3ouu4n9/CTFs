##### Building the docker
`docker build -t cop .`

##### Running the docker
`docker run -p localhost:6666:6666 cop`