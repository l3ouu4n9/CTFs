#### Hi COP

I wrote a game that should be impossible to win.

A friend of mine managed to get the flag in a few seconds.

Can you help me find out how?

![ALT](/COP/COP/cop.gif)

