run and build using:
docker compose up --build