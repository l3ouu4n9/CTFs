LAYOUT = (
	{
		"name": "@TEXT",
		"prot": "rx",
		"vmaddr": 0x0100
	},
	{
		"name": "@DATA",
		"prot": "rw"
	}
)

ENTRYPOINTS = [
	"@main"
]
