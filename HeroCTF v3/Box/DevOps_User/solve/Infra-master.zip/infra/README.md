# Infra

Some docker configuration files to build this awesome machine.