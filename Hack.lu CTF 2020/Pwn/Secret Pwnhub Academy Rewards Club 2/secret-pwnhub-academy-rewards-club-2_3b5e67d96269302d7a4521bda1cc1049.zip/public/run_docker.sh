#!/bin/bash
docker run -p 4444:4444 -it sparc-2 $@