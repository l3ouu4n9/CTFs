function addComment(line, filename, id) {
    const comment = prompt("Please enter comment", "Great code!");
    $.ajax({
        type: "POST",
        url: "/addComment",
        data: JSON.stringify({id: id, file: filename, line: line, comment: comment}),
        success: function (data) {
            location.reload();
        },
        dataType: "json",
        contentType: "application/json"
    });
}