#!/bin/sh
#

service xinetd restart && sleep infinity
