URL=https://swdl.bluejeans.com/desktop-app/linux/2.17.0/BlueJeans_2.17.0.11.deb
DEST=task-env/BlueJeans_2.17.0.11.deb
[ -f $DEST ] || wget $URL -O $DEST
docker build ds-desktop-enviroment -t ds-desktop-enviroment
