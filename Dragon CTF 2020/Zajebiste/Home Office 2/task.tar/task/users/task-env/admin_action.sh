# install video conference software
sudo dpkg -i /home/admin/data/BlueJeans_2.17.0.11.deb

# fake http server
nc -l -p 8080 < /home/admin/data/response.txt &
sleep 1

# visit link with redirect to meeting
firefox http://127.0.0.1:8080/ &
sleep 45

# switch to open button and enter
WND=`xdotool search --name "Mozilla Firefox"`
echo "got wnd: $WND"
for i in $(seq 1 4); do
  xdotool key --window "$WND" Tab
  echo "tab $i"
  sleep 1
done
xdotool key --window "$WND" Return
sleep 1000
