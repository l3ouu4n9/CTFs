# Thy Son

```
docker build -t acsc-thyson .
docker run -p 5145:5145 --rm acsc-thyson
```
