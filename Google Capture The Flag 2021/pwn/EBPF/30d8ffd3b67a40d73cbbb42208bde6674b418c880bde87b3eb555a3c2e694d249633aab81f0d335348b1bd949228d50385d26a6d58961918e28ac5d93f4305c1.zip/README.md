# EBPF

This chllange is using Busybox ([source code](https://busybox.net/source.html)).

To run the challenge locally edit `start.sh` to fix kernel and initramfs paths and run it.
