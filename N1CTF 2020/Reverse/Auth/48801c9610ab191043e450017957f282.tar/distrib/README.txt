Hello, welcome to N1CTF 2020! This is a Windows challenge that requires you to develop your own program to interact with the binary given.

This challenge runs on a Windows Server 2019 (version 17763.1518). A relatively new version of Windows 10 should be the same in order to make everything work.
The flag is in the server at C:\flag.txt.

Here are the details of the attachments:

* auth.exe - The challenge binary, RE this and interact with it to get the flag.
* sandbox.exe, jsoncpp.dll - This is the sandbox program that is used to securely run your solution. This is not the target, check https://github.com/marche147/sandbox for the implementation.
* sandbox.json - Sandbox profile that will be used by sandbox.exe.
* deploy.bat - Extra setups for the challenge environment, you might want to read it.
* service.py - The service that will be interacting with you upon connection. This script should be run as SYSTEM. If you want to have a shell running locally with SYSTEM privilege, try PsExec from SysInternals suite.

Some hints :
1. Try to tweak the parameters in sandbox.json, you should try to figure out what is limited by the sandbox. The solution should work under the sandboxed environment.
2. Disable `stdout` buffering. Sometimes if your program crashed/exited midway, you will not get the output if buffering is enabled.
3. Build your solution with static VC runtime. You should assume there's no VC runtime installed on the server.

The setup for the challenge is not trivial and things might go wrong. If you find the service malfunctioning, or get into some strange problem, don't hesitate contacting admins.

Have fun, and good luck.
- shiki7
