Hello!

We are going to have some fun and play my fav game: https://github.com/Drewol/unnamed-sdvx-clone

You can grab it prebuilt from here:

Windows: https://drewol.me/Downloads/Game.zip
Linux (needs github login): https://github.com/Drewol/unnamed-sdvx-clone/suites/1128119397/artifacts/16053517

You can then put the `flagsong` directory into the `songs` directory of USC to play it

Now for the actual challenge:
You have to retrieve the real flag from `./flagsong/flag.ksh` on my computer
(Your copy doesn't have the real flag in it).


My bot (who has the real flag song) will play multiplayer with you if you like.
It will be using https://github.com/itszn/usc-multiplayer-server
on 34.234.204.29 port 39079 (this can be set in the USC settings under online)

The multiplayer sever will restart every 15 min

NOTE: Some functionality of the bot has been simplified for this challenge
but the intended bug left intact. If you think you have a bug that won't
reproduce on the real bot, message me (itszn) and I can test the full, unaltered,
client for you. The client the bot is using should be feature equivalent to
git commit 649b444485db4b1f6dfa0e6adab90dd242764394

Also in case you need it, my computer is running Windows 10
(but you probably don't need to know this...)

ALSO if you are actually good at SDVX, let me know and we can play
some real matches :)
