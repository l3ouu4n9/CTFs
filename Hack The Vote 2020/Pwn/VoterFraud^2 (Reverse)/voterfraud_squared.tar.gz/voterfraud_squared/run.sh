#!/bin/sh

exec ./launcher ./rootkit ./dummy_flag.txt
