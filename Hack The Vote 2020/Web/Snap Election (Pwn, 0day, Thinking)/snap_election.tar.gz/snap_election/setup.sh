#!/bin/sh

sudo apt-get install python3 python3-pip
pip3 install flask

sudo snap install htv-vote-counter

