Web Starter Kit -- Torque HTTP Server

The server is running this same install except with the real flags.
Feel free to join the game with this client while you hack though! 

