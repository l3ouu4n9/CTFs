#!/bin/sh
rackup --port 8080 --host 0.0.0.0
