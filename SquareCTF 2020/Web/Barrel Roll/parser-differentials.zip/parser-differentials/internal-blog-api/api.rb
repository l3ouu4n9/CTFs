require 'grape'
require 'json'

class Post
	def initialize(name, contents)
		@name = name
		@contents = contents
		@likes = 0
	end

	def newLike()
		@likes = @likes + 1
	end

	def contents()
		return @contents
	end

	def to_h()
		return {'name' => @name, 'likes' => @likes}
	end
end

POSTS = {
	'FLAG' => Post.new("FLAG", "flag{parsers_really_arent_all_that_different}"),
	'INTRO' => Post.new("INTRO", "Welcome to my REST API Blog!"),
}

module Blog
	class API < Grape::API
		format :json

		# Returns a list of post names and number of likes
		get 'list' do
			status 200
			return POSTS.map {|k,v| v.to_h()}
		end

		# Returns the contents of a given post
		get 'contents/:postName' do
			postName = params[:postName]
			if POSTS.key?(postName)
				status 200
				return POSTS[postName].contents
			else
				error!("No such post", 404)
			end
		end

		# Adds a like to a post
		post 'like/:postName' do
			postName = params[:postName]
			if POSTS.key?(postName)
				POSTS[postName].newLike()
				status 200
				return {}
			else
				error!("No such post", 404)
			end
		end
	end
end
