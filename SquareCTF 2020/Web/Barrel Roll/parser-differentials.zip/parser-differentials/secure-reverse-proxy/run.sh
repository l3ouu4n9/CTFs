#!/bin/sh
go run main.go
