package main

import (
	"log"
	"net/http"
	"net/http/httputil"
	"net/url"

	"github.com/gorilla/mux"
)

func main() {
	blogApi, _ := url.Parse("http://internal-blog-api:8080")
	log.Printf("forwarding to %s\n", blogApi)

	proxy := httputil.NewSingleHostReverseProxy(blogApi)
	r := mux.NewRouter()

	// Prevent someone from getting a hidden blog post
	r.PathPrefix("/contents/FLAG").Methods("GET").HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		http.Error(w, "Forbidden", 403)
	})

	// Pass all other requests to the blog api
	r.PathPrefix("/").HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		req.Host = req.URL.Host
		proxy.ServeHTTP(w, req)
	})

	http.ListenAndServe(":8090", r)
}
