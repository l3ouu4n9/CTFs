#/bin/sh
./encryptor -i ./flag.txt -o ./flag.enc
