#!/bin/bash
while :; do
    ./sendmsg.py
done
