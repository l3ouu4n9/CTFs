The soundtrack used is here is "Exit This Earth's Atomosphere" by Camellia (かめりあ). Big thanks to the god tier composer!

You'll need a game client to play .ksh files.
The most popular ones are Unnamed SDVX Clone (https://github.com/Drewol/unnamed-sdvx-clone) and K-Shoot MANIA (https://www.kshootmania.com/).
Unnamed SDVX Clone runs a lot smoother, but K-Shoot MANIA comes with a very handy map editor.
Copy the entire ctf-song/ directory into your game's songs directory to play it.

I have encoded the flag and hidden it in ctf-song/grv.ksh using the Next Generation Steganography, as well as adding various effects to the song.
Go find the flag!


Notes:
1. The audio file was taken from Camellia's osu! song listings (this use is allowed, see his song usage policies for details), and does not contain any information required to get the flag.
2. The jacket.png file also does not contain any flag-related information. (This image is drawn by me, and is released under CC-BY. What a masterpiece.)
