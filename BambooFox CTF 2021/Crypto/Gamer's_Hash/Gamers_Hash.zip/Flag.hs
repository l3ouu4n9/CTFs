module Flag where

flag = "[DATA EXPUNGED]"
