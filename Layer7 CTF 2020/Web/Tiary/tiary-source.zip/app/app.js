const express = require("express");
const bodyParser = require("body-parser");
const session = require("express-session");
const webdriver = require("selenium-webdriver");
const chrome = require("selenium-webdriver/chrome");
const { assert } = require("console");
const fetch = require('node-fetch');
const { sha256, random_bytes } = require("./utils");
const fs = require("fs");

const options = new chrome.Options();
const capabilities = webdriver.Capabilities.chrome();

let driver;
let password = sha256(random_bytes(64))
const HOST = 'http://211.239.124.243:18603/'
function reloadDriver() {

    if (driver) {
        driver.quit();
    }

    driver = new webdriver.Builder()
        .usingServer('http://selenium:4444/wd/hub/')
        .withCapabilities(capabilities)
        .setChromeOptions(options)
        .build();

    driver.get(HOST).then(() => {
        fetch(HOST + 'login', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `username=admin&password=${password}`,
            redirect: 'manual'
        })
            .then(data=>{
                const session = data.headers.raw()['set-cookie'][0].split(';')[0].split('=')[1];
                driver.manage().addCookie({name:'connect.sid', value: session});
            })
    });
}

setInterval(() => {
    reloadDriver();
}, 5000);

const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(
    session({
        secret: random_bytes(64),
    })
);

app.engine("html", require("ejs").renderFile);
app.set("view engine", "html");

const users = new Map([
    ["admin", sha256(password)],
]);

const notes = new Map([
    ["admin", [{
        key: sha256(random_bytes(64)),
        title: 'flag',
        content: fs.readFileSync('/flag').toString()
    }]]
]);

app.all("/", (req, res) => {
    if (!req.session.username) {
        res.redirect("/login");
    } else {
        res.render("index", { username: req.session.username, notes: notes.get(req.session.username) || [] });
    }
});

app.post('/write', (req, res) => {
    if (!req.session.username) {
        res.redirect('/');
    }
    
    const { title, content } = req.body;

    assert(title && typeof title === "string" && title.length < 100);
    assert(content && typeof content === "string" && content.length < 400);

    const key = sha256(random_bytes(64));

    const user_notes = notes.get(req.session.username) || [];
    user_notes.push({
        key,
        title,
        content
    });
    notes.set(req.session.username, user_notes);

    res.redirect('/');
});

app.get('/read', (req, res) => {
    if (!req.session.username) {
        res.redirect('/');
    }

    res.render('read'); 
});

app.get('/read/:id', (req, res) => {
    if (!req.session.username) {
        res.redirect('/');
    }

    const { id } = req.params;

    const user_notes = notes.get(req.session.username);
    const found = user_notes && user_notes.find(note => note.key === id);

    if (found) {
        res.json({title: found.title, content: found.content});
    } else {
        res.json({title: '404 not found', content: 'no such note'});
    }
});

app.all("/logout", (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

app.get("/report", (req, res) => {
    if (!req.session.username) {
        res.redirect('/');
    }
    res.render("report", {submit: false, host: HOST});
});

app.post("/report", (req, res) => {
    if (!req.session.username) {
        res.redirect('/');
    }
    const url = req.body.url && req.body.url.trim();

    if (typeof url === 'string' && url.substr(0, HOST.length) === HOST) {
        (async () => {
            console.log(url);
            await driver.get(url);
            await res.end('Your request has been processed');
        })();
    } else {
        res.send('<script>alert("Invalid URL!"); history.back();</script>');
    }
});

app.get("/login", (req, res) => {
    if (req.session.username) {
        res.redirect('/');
    }
    res.render("login");
});


app.all("/login", (req, res) => {
    if (req.session.username) {
        res.redirect('/');
    }
    const { username, password } = req.body;

    assert(username && typeof username === "string" && username.length < 100);
    assert(password && typeof password === "string" && password.length < 100);

    if (users.has(username)) {
        if (users.get(username) === sha256(password)) {
            req.session.username = username;

            res.redirect("/");
        } else {
            res.render("login", { msg: "Invalid Password" });
        }
    } else {
        users.set(username, sha256(password));
        req.session.username = username;

        res.redirect("/");
    }
});

app.listen(8080);
