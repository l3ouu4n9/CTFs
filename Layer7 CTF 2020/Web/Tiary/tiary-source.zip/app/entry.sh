#!/usr/bin/env bash

cd /app
npm install
npm install -y nodemon -g
nodemon app.js