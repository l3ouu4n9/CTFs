#!/usr/bin/env bash

node /app/app.js