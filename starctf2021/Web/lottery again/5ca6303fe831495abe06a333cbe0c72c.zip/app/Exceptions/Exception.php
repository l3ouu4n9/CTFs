<?php

namespace App\Exceptions;

use Exception as BaseException;

class Exception extends BaseException {

}
