#!/usr/bin/env bash

exec python3  app.py &
exec python3  client.py