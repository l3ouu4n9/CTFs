<?php
$key='None';
