#!/bin/bash


cd /steg/www && su -c '/steg/www/server.py' steg
